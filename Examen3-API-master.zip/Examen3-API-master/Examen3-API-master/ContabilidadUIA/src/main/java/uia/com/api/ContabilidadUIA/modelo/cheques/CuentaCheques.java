package uia.com.api.ContabilidadUIA.modelo.cheques;

public class CuentaCheques {

}
