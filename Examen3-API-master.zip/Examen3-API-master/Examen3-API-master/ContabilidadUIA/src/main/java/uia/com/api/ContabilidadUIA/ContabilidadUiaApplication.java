package uia.com.api.ContabilidadUIA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContabilidadUiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContabilidadUiaApplication.class, args);
	}

}
